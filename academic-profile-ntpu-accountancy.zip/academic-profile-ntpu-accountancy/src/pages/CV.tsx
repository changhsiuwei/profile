import Layout from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function CV() {
  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold font-heading text-primary mb-2">Curriculum Vitae</h1>
          <p className="text-muted-foreground">Updated: 2025</p>
        </div>

        {/* Education */}
        <Section title="Education">
          <Entry 
            title="Ph.D. in Accounting"
            org="National Taiwan University (國立臺灣大學)"
            period="Sep 2019 – June 2024"
            location="Taipei, Taiwan"
            details={[
              "Dissertation: https://tdr.lib.ntu.edu.tw/handle/123456789/92755?locale=en"
            ]}
          />
          <Entry 
            title="Visiting Ph.D. Student (IVGS)"
            org="University of Toronto (多倫多大學)"
            period="May 2023 – Dec 2023"
            location="Ontario, Canada"
            details={["Rotman School of Management"]}
          />
          <Entry 
            title="M.A. in Taxation and Finance Management"
            org="National Taichung University of Science and Technology"
            period="June 2015"
            location="Taichung, Taiwan"
          />
          <Entry 
            title="B.S. in Public Finance and Taxation"
            org="National Taichung University of Science and Technology"
            period="June 2013"
            location="Taichung, Taiwan"
          />
        </Section>
        
        <Separator />

        {/* Experience */}
        <Section title="Professional Experience">
           <Entry 
            title="Analyst (分析員)"
            org="KPMG Taiwan (安侯建業聯合會計師事務所國際稅務部)"
            period="Feb 2022 – Sep 2022"
            location="Taiwan"
            details={["Outbound Tax and Investment Services"]}
          />
          <Entry 
            title="Tax Executive (稅務員)"
            org="National Taxation Bureau of Taipei, Ministry of Finance (財政部臺北國稅局徵收科)"
            period="June 2018 – Aug 2019"
            location="Taipei, Taiwan"
          />
        </Section>

        <Separator />

        {/* Awards */}
        <Section title="Honors & Awards">
          <ul className="space-y-3 mt-4">
            <AwardItem title="Excellence Award, the 17th TSC Thesis Award 2024" />
            <AwardItem title="NTU Presidential Award for Graduate Students, Academic Year 2023" />
            <AwardItem title="2023 NSTC Ph.D. Students Study Abroad Program" details="Accounting, Rotman School of Management, University of Toronto" />
            <AwardItem title="Best Academic Paper Award" details="2025 Taiwan Accounting Association Annual Conference (x2)" />
          </ul>
        </Section>

        <Separator />

        {/* Service */}
        <Section title="Service">
           <Entry 
            title="會計教育AI應用兼任研究員"
            org="中華會計學會"
            period="April 2025 – June 2025"
          />
        </Section>
      </div>
    </Layout>
  );
}

function Section({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <section>
      <h2 className="text-2xl font-bold font-heading text-primary mb-6">{title}</h2>
      <div className="space-y-8">
        {children}
      </div>
    </section>
  );
}

function Entry({ title, org, period, location, details }: any) {
  return (
    <div className="relative pl-4 border-l-2 border-slate-100">
       <div className="flex justify-between items-start flex-wrap gap-2 mb-1">
         <h3 className="font-bold text-lg text-foreground">{title}</h3>
         <span className="text-sm font-medium text-muted-foreground bg-slate-50 px-2 py-1 rounded">{period}</span>
       </div>
       <div className="text-secondary-foreground font-medium mb-1">{org}</div>
       {location && <div className="text-sm text-slate-500 mb-2">{location}</div>}
       {details && (
         <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
           {details.map((d: string, i: number) => <li key={i}>{d}</li>)}
         </ul>
       )}
    </div>
  );
}

function AwardItem({ title, details }: any) {
  return (
    <li className="flex items-start gap-2">
      <Badge variant="outline" className="mt-1 border-yellow-400 text-yellow-600">Award</Badge>
      <div>
        <div className="font-medium text-foreground">{title}</div>
        {details && <div className="text-sm text-muted-foreground">{details}</div>}
      </div>
    </li>
  );
}
