import Layout from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, ScrollText, Mic2 } from "lucide-react";

export default function Publications() {
  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold font-heading text-primary mb-2">學術出版</h1>
          <p className="text-muted-foreground text-lg">Publications, Working Papers & Conference Presentations</p>
        </div>

        <Tabs defaultValue="journal" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="journal" className="gap-2"><FileText className="w-4 h-4"/> Journal Publications</TabsTrigger>
            <TabsTrigger value="working" className="gap-2"><ScrollText className="w-4 h-4"/> Working Papers</TabsTrigger>
            <TabsTrigger value="conference" className="gap-2"><Mic2 className="w-4 h-4"/> Conferences</TabsTrigger>
          </TabsList>

          <TabsContent value="journal" className="space-y-6">
            <PublicationItem 
              authors="Wu, T. C., Chang, C. J.*, & Chang, H. W."
              year="2025"
              title="The Choice of International Commodity Tax Principles Revisited: The Role of Interest Groups and Foreign Ownership"
              journal="Scottish Journal of Political Economy"
              note="SCI impact factor 1.2; SSCI; 國科會經濟學門評比B+級期刊"
            />
            <PublicationItem 
              authors="Wu, T. C., Chang, C. J.*, & Chang, H. W."
              year="2025"
              title="Multinational upstream firm and commodity tax principle under origin and destination principles"
              journal="International Tax and Public Finance"
              pages="1-41"
              note="SCI impact factor 1.0; SSCI; 國科會經濟學門學術期刊評比 B+級期刊"
            />
            <PublicationItem 
              authors="Chang, H. W.*, Wang, P. Y., & Yu, J. W."
              year="2025"
              title="When the Material Information Is Not ‘Material’: The Dynamics of Disclosure Under China's Zero-Covid Policy"
              journal="Journal of Accounting Review"
              volume="80(1)"
              pages="164-241"
              doi="10.6552/JOAR.202501_(80).0004"
              note="TSSCI 評鑑會計類核心第一級期刊"
            />
            <PublicationItem 
              authors="Wu, T. C., Yen, C. T.*, & Chang, H. W."
              year="2023"
              title="Network externalities, trade costs, and the choice of commodity taxation principle"
              journal="International Tax and Public Finance"
              volume="30(5)"
              pages="1203-1224"
              note="SCI impact factor 1.0; SSCI; 國科會經濟學門學術期刊評比 B+級期刊"
            />
          </TabsContent>

          <TabsContent value="working" className="space-y-6">
             <PublicationItem 
              authors="Chang, H. W., Wang, T., & Liu, C."
              year="2023"
              title="The Moderating Role of Corporate Governance under Tariff Shocks: Evidence from the US-China Trade War"
              journal="Available at SSRN 4464559"
            />
            <PublicationItem 
              authors="Chia-Jen Chang*, Tsaur-Chin Wu, & **Hsiu-Wei Chang**"
              title="The Choice of International Commodity Tax Principle Revisited: The Role of Interest Groups and Foreign Ownership"
              journal="Scottish Journal of Political Economy"
              note="under review, 2nd Round; SCI impact factor 0.9; SSCI; 國科會國際期刊經濟學B+級期刊"
            />
          </TabsContent>

          <TabsContent value="conference" className="space-y-6">
            <ConferenceItem 
              title="2025 Taiwan Accounting Association Annual Conference, Taipei"
              papers={[
                "名人執行長公開背書對供應鏈夥伴的影響：投資人注意力、股價反應與意見分歧之分析 (Best Academic Paper Award)",
                "Pricing the Blame: How Event Attribution Shapes Audit Fees in Corporate Groups (Best Academic Paper Award)"
              ]}
            />
            <ConferenceItem 
              title="2023 Taiwan Accounting Association Annual Conference, Taipei"
              papers={["Navigating Supply Chain Crises: The Impact of Material Information Disclosure Amid China's Zero–COVID Policy"]}
            />
             <ConferenceItem 
              title="2022 Taiwan Accounting Association Annual Conference, Tainan"
              papers={["The Moderating Role of Accounting Quality under the Tariff Shock – Evidence from U.S.-China Trade War"]}
            />
            <ConferenceItem 
              title="2022 AAA/Deloitte Foundation/J. Michael Cook Doctoral Consortium, Texas"
              papers={["The Moderating Role of Accounting Quality under the Tariff Shock – Evidence from U.S.-China Trade War"]}
            />
            <ConferenceItem 
              title="2021 Taiwan Economic Association, Taipei"
              papers={["Network Externalities, Trade Costs, and the Choice of Commodity Taxation Principles"]}
            />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}

function PublicationItem({ authors, year, title, journal, volume, pages, doi, note }: any) {
  return (
    <Card className="border-l-4 border-l-secondary shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="mb-2 text-sm text-muted-foreground font-medium">
          {authors} {year && `(${year})`}
        </div>
        <h3 className="text-lg font-bold text-primary mb-2 leading-snug">{title}</h3>
        <div className="text-base font-serif italic mb-2">
          {journal} {volume && `, ${volume}`} {pages && `, ${pages}`}
        </div>
        {doi && (
           <a href={`http://dx.doi.org/${doi}`} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 hover:underline block mb-2">
             DOI: {doi}
           </a>
        )}
        {note && (
          <Badge variant="outline" className="mt-2 bg-slate-50 text-xs font-normal text-slate-600 border-slate-200">
            {note}
          </Badge>
        )}
      </CardContent>
    </Card>
  );
}

function ConferenceItem({ title, papers }: { title: string, papers: string[] }) {
  return (
    <div className="pl-4 border-l-2 border-slate-200 py-2">
      <h4 className="font-bold text-foreground mb-2">{title}</h4>
      <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
        {papers.map((paper, i) => (
          <li key={i}>{paper}</li>
        ))}
      </ul>
    </div>
  );
}
