import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, Landmark, Gavel, FileSearch, ChartBar } from "lucide-react";
import researchAbstract from "@/assets/research_abstract.jpeg";

const RESEARCH_AREAS = [
  {
    title: "Artificial Intelligence Applications in Accounting",
    icon: Brain,
    description: "Investigating the transformative impact of AI on auditing, financial reporting, and decision-making processes."
  },
  {
    title: "Capital Market",
    icon: TrendingUp,
    description: "Analyzing market behaviors, efficiency, and the impact of financial information on stock prices."
  },
  {
    title: "Corporate Tax",
    icon: Landmark,
    description: "Examining corporate tax strategies, compliance, and policy implications."
  },
  {
    title: "Corporate Governance",
    icon: Gavel,
    description: "Studying the mechanisms, processes, and relations by which corporations are controlled and directed."
  },
  {
    title: "Disclosure Theory",
    icon: FileSearch,
    description: "Understanding the incentives and consequences of voluntary and mandatory corporate disclosures."
  },
  {
    title: "Event Study",
    icon: ChartBar,
    description: "Methodological application to assess the impact of specific events on the value of a firm."
  }
];

export default function Research() {
  return (
    <Layout>
      <div className="space-y-12">
        {/* Header */}
        <div className="relative rounded-2xl overflow-hidden bg-primary text-primary-foreground p-8 md:p-12">
          <div className="absolute inset-0 opacity-20">
             <img src={researchAbstract} alt="Research Abstract" className="w-full h-full object-cover" />
          </div>
          <div className="relative z-10 max-w-2xl">
            <h1 className="text-3xl md:text-4xl font-bold font-heading mb-4">研究領域</h1>
            <h2 className="text-xl opacity-90 font-light">Areas of Interest & Research Methodology</h2>
            <p className="mt-6 text-primary-foreground/80 leading-relaxed">
              My research focuses on the intersection of modern technology and traditional accounting principles, utilizing quantitative methods to uncover insights in capital markets and corporate behavior.
            </p>
          </div>
        </div>

        {/* Research Areas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {RESEARCH_AREAS.map((area, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all hover:-translate-y-1 border-t-4 border-t-transparent hover:border-t-secondary">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary-foreground mb-4 group-hover:bg-secondary group-hover:text-white transition-colors">
                  <area.icon className="w-6 h-6" />
                </div>
                <CardTitle className="text-xl font-bold">{area.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {area.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}
