import Layout from "@/components/Layout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Users, MapPin } from "lucide-react";

export default function Teaching() {
  return (
    <Layout>
      <div className="space-y-12">
        <div>
          <h1 className="text-3xl font-bold font-heading text-primary mb-2">教學經歷</h1>
          <p className="text-muted-foreground text-lg">Teaching Experience & Invited Presentations</p>
        </div>

        {/* Academic Courses */}
        <section>
          <h2 className="text-2xl font-bold font-heading text-primary mb-6 flex items-center gap-2">
            <span className="w-8 h-1 bg-secondary rounded-full inline-block"></span>
            Academic Courses
          </h2>
          <div className="grid gap-6 md:grid-cols-2">
            <TeachingCard 
              role="Adjunct Assistant Professor"
              dept="Dept. of Public Finance and Taxation"
              uni="National Taichung University of Science and Technology"
              period="August 2024 – June 2025"
              courses={["Auditing (審計學)"]}
            />
            <TeachingCard 
              role="Adjunct Assistant Professor"
              dept="Dept. of Public Finance and Taxation"
              uni="Feng Chia University"
              period="August 2024 – June 2025"
              courses={["Cost Accounting (成本會計)", "International Finance (國際金融)"]}
            />
          </div>
        </section>

        {/* Invited Presentations */}
        <section>
           <h2 className="text-2xl font-bold font-heading text-primary mb-6 flex items-center gap-2">
            <span className="w-8 h-1 bg-secondary rounded-full inline-block"></span>
            Invited Presentations (2025)
          </h2>
          <div className="bg-white rounded-xl border shadow-sm p-6 space-y-6 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/5 rounded-full -mr-16 -mt-16" />
             
             <TimelineItem 
               date="Dec 6" 
               org="Business Accounting Association (中華企業會計協會，正大聯合會計師事務所)" 
               topic="AI 在公司內部的應用場景與展望" 
             />
             <TimelineItem 
               date="Nov 28" 
               org="National Taiwan University (中華會計教育學會年會)" 
               topic="AI 輔助教學：授課教師的應用場景與實踐" 
             />
             <TimelineItem 
               date="Sep 25" 
               org="Mackay Memorial Hospital (馬偕醫院急診科)" 
               topic="AI賦能急診醫師：從學習到研究的智慧化轉型" 
             />
             <TimelineItem 
               date="Sep 23" 
               org="ASUSTeK Computer Inc. (華碩財務部)" 
               topic="賦能財務新未來：AI 驅動的智慧自動化解決方案" 
             />
             <TimelineItem 
               date="Sep 9" 
               org="NTU Master Program in Accounting" 
               topic="情境提示詞工程在企業價值管理與數據分析之應用" 
             />
             <TimelineItem 
               date="Aug 27" 
               org="NTPU Executive Master Program in Accounting" 
               topic="人工智慧的最新現況：從過去歷史獲得未來啟示" 
             />
             <TimelineItem 
               date="Aug 12" 
               org="Chang Gung University EMBA" 
               topic="機器學習在管理會計銷售預測中的應用：理論基礎與實務指南" 
             />
          </div>
        </section>
      </div>
    </Layout>
  );
}

function TeachingCard({ role, dept, uni, period, courses }: any) {
  return (
    <Card className="hover:border-secondary transition-colors">
      <CardHeader>
        <div className="text-xs font-bold text-secondary-foreground uppercase tracking-wider mb-2">{role}</div>
        <CardTitle className="text-lg leading-snug mb-1">{uni}</CardTitle>
        <div className="text-sm text-muted-foreground">{dept}</div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-4">
          <Calendar className="w-4 h-4" /> {period}
        </div>
        <div className="flex flex-wrap gap-2">
          {courses.map((c: string, i: number) => (
            <Badge key={i} variant="secondary" className="bg-slate-100 text-slate-700 hover:bg-slate-200">
              {c}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function TimelineItem({ date, org, topic }: any) {
  return (
    <div className="flex gap-4 group">
      <div className="flex-none w-16 pt-1 text-sm font-bold text-secondary-foreground/70 text-right">{date}</div>
      <div className="flex-1 pb-6 border-l-2 border-slate-100 pl-6 relative last:pb-0 last:border-l-0">
        <div className="absolute left-[-5px] top-2 w-2 h-2 rounded-full bg-secondary group-hover:scale-125 transition-transform" />
        <h4 className="font-bold text-foreground mb-1 group-hover:text-primary transition-colors">{org}</h4>
        <p className="text-sm text-muted-foreground">{topic}</p>
      </div>
    </div>
  );
}
