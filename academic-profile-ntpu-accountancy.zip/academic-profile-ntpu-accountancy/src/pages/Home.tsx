import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Star } from "lucide-react";
import heroBg from "@/assets/hero_bg.jpeg";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  return (
    <Layout>
      <div className="space-y-16">
        {/* Hero Section */}
        <section className="relative rounded-3xl overflow-hidden shadow-2xl isolate">
          <img 
            src={heroBg} 
            alt="Hero Background" 
            className="absolute inset-0 w-full h-full object-cover -z-10"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-transparent -z-10" />
          
          <div className="p-8 md:p-16 max-w-2xl space-y-6">
            <Badge variant="secondary" className="mb-2 bg-secondary/80 hover:bg-secondary/90 backdrop-blur-sm text-secondary-foreground font-semibold px-4 py-1.5 rounded-full">
              Assistant Professor at NTPU
            </Badge>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold font-heading tracking-tight text-primary leading-tight">
              Exploring the Future of <span className="text-secondary-foreground">Accounting & AI</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Dedicated to bridging the gap between traditional accounting principles and modern artificial intelligence applications.
            </p>
            
            <div className="pt-4 flex flex-wrap gap-4">
              <Link href="/research">
                <Button size="lg" className="rounded-full px-8 text-base shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
                  Explore Research <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" size="lg" className="rounded-full px-8 text-base bg-white/50 backdrop-blur-sm hover:bg-white/80">
                  Contact Me
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Motto Section */}
        <section className="text-center space-y-6 max-w-3xl mx-auto py-8">
           <div className="inline-flex items-center justify-center p-3 rounded-full bg-orange-100 text-orange-600 mb-4">
             <Star className="w-6 h-6 fill-current" />
           </div>
           <blockquote className="text-2xl md:text-3xl font-heading font-medium text-foreground italic">
             "Honoring God and benefiting people!"
           </blockquote>
           <p className="text-lg text-muted-foreground">(榮神益人！)</p>
        </section>

        {/* Highlights Grid */}
        <section className="grid md:grid-cols-3 gap-8">
          <div className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 hover:border-secondary/50 transition-colors">
            <h3 className="text-xl font-bold font-heading mb-3 text-primary">Research Focus</h3>
            <p className="text-muted-foreground mb-4">
              Artificial Intelligence Applications, Capital Markets, Corporate Tax, and Governance.
            </p>
            <Link href="/research">
              <span className="text-sm font-semibold text-secondary-foreground hover:underline cursor-pointer">Learn more &rarr;</span>
            </Link>
          </div>

          <div className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 hover:border-secondary/50 transition-colors">
            <h3 className="text-xl font-bold font-heading mb-3 text-primary">Publications</h3>
            <p className="text-muted-foreground mb-4">
              Featured in Scottish Journal of Political Economy, International Tax and Public Finance, and more.
            </p>
            <Link href="/publications">
              <span className="text-sm font-semibold text-secondary-foreground hover:underline cursor-pointer">View publications &rarr;</span>
            </Link>
          </div>

          <div className="bg-card p-6 rounded-2xl shadow-sm border border-border/50 hover:border-secondary/50 transition-colors">
             <h3 className="text-xl font-bold font-heading mb-3 text-primary">Teaching</h3>
             <p className="text-muted-foreground mb-4">
               Empowering students with knowledge in Accounting, Auditing, and AI applications.
             </p>
             <Link href="/teaching">
               <span className="text-sm font-semibold text-secondary-foreground hover:underline cursor-pointer">See courses &rarr;</span>
             </Link>
          </div>
        </section>
      </div>
    </Layout>
  );
}
