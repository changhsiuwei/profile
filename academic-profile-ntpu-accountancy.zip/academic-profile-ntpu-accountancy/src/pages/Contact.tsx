import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Phone, ExternalLink } from "lucide-react";

export default function Contact() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-12">
         <div>
          <h1 className="text-3xl font-bold font-heading text-primary mb-2">聯絡方式</h1>
          <p className="text-muted-foreground text-lg">Get in touch for collaboration or inquiries</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            <ContactCard 
              icon={Mail} 
              title="Email" 
              value="andychang@mail.ntpu.edu.tw" 
              action="mailto:andychang@mail.ntpu.edu.tw"
            />
            <ContactCard 
              icon={MapPin} 
              title="Office" 
              value="商 6F38, National Taipei University" 
            />
            <ContactCard 
              icon={Phone} 
              title="Phone" 
              value="(02) 8674-1111 #66685" 
            />
            
            <a 
              href="https://scholar.google.com.tw/citations?user=X130FHEAAAAJ&hl=zh-TW" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors border border-blue-100"
            >
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                <ExternalLink className="w-5 h-5" />
              </div>
              <div>
                <div className="font-bold">Google Scholar Profile</div>
                <div className="text-sm opacity-80">View citations and full list</div>
              </div>
            </a>
          </div>

          {/* Contact Form (Static) */}
          <div className="bg-card rounded-xl border shadow-sm p-6">
            <h3 className="text-xl font-bold mb-4">Send a Message</h3>
            <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
              <div className="space-y-2">
                <label className="text-sm font-medium">Name</label>
                <Input placeholder="Your Name" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <Input type="email" placeholder="your@email.com" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Message</label>
                <Textarea placeholder="How can I help you?" className="min-h-[120px]" />
              </div>
              <Button type="submit" className="w-full">Send Message</Button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function ContactCard({ icon: Icon, title, value, action }: any) {
  const Content = () => (
    <div className="flex items-center gap-4 p-4 rounded-xl bg-card border hover:border-secondary transition-colors group cursor-pointer shadow-sm">
      <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center text-secondary-foreground group-hover:bg-secondary group-hover:text-white transition-colors">
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{title}</div>
        <div className="font-medium text-foreground">{value}</div>
      </div>
    </div>
  );

  if (action) {
    return <a href={action}>{Content()}</a>;
  }
  return Content();
}
