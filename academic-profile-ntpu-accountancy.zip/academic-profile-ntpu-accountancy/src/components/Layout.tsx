import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Home, BookOpen, FileText, GraduationCap, User, Mail, ExternalLink } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import sidebarBg from "@/assets/sidebar_bg.jpeg";
import profileImg from "@/assets/profile.png";

const NAV_ITEMS = [
  { label: "首頁 (Home)", path: "/", icon: Home },
  { label: "研究領域 (Research)", path: "/research", icon: BookOpen },
  { label: "學術出版 (Publications)", path: "/publications", icon: FileText },
  { label: "教學經歷 (Teaching)", path: "/teaching", icon: GraduationCap },
  { label: "個人履歷 (CV)", path: "/cv", icon: User },
  { label: "聯絡方式 (Contact)", path: "/contact", icon: Mail },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Handle scroll effect for mobile header
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const SidebarContent = () => (
    <div className="flex flex-col h-full text-white relative overflow-hidden">
      {/* Background Image Overlay */}
      <div 
        className="absolute inset-0 z-0 opacity-20 bg-cover bg-center"
        style={{ backgroundImage: `url(${sidebarBg})` }}
      />
      <div className="absolute inset-0 z-0 bg-sidebar-primary/90 mix-blend-multiply" />
      
      {/* Profile Section */}
      <div className="relative z-10 p-8 flex flex-col items-center text-center border-b border-white/10">
        <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white/20 mb-6 shadow-xl relative group">
           <img src={profileImg} alt="Hsiu-Wei Chang" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-2xl font-bold mb-1 tracking-tight font-heading">張修瑋</h1>
        <p className="text-sm font-medium opacity-90 mb-1">Hsiu-Wei Chang</p>
        <p className="text-xs uppercase tracking-widest opacity-70 mb-4">Assistant Professor</p>
        <div className="text-xs opacity-80 leading-relaxed max-w-[200px]">
          Department of Accountancy<br/>
          National Taipei University
        </div>
      </div>

      {/* Navigation */}
      <nav className="relative z-10 flex-1 py-6 px-4 space-y-2 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.path;
          return (
            <Link key={item.path} href={item.path}>
              <a
                onClick={() => setIsMobileOpen(false)}
                className={cn(
                  "flex items-center gap-4 px-4 py-3 rounded-lg transition-all duration-300 group",
                  isActive 
                    ? "bg-white/15 text-white shadow-lg backdrop-blur-sm translate-x-1" 
                    : "text-white/70 hover:bg-white/5 hover:text-white hover:translate-x-1"
                )}
              >
                <item.icon className={cn("w-5 h-5 transition-transform group-hover:scale-110", isActive && "scale-110")} />
                <span className="font-medium tracking-wide text-sm">{item.label}</span>
              </a>
            </Link>
          );
        })}
      </nav>

      {/* Footer / External Links */}
      <div className="relative z-10 p-6 border-t border-white/10">
        <a 
          href="https://scholar.google.com.tw/citations?user=X130FHEAAAAJ&hl=zh-TW" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-xs text-white/60 hover:text-white transition-colors justify-center"
        >
          <ExternalLink className="w-3 h-3" />
          Google Scholar Profile
        </a>
        <div className="mt-4 text-[10px] text-center text-white/40">
          © {new Date().getFullYear()} Hsiu-Wei Chang
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background font-body text-foreground flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-80 fixed inset-y-0 left-0 bg-sidebar-primary shadow-2xl z-50">
        <SidebarContent />
      </aside>

      {/* Mobile Header */}
      <div className={cn(
        "md:hidden fixed top-0 left-0 right-0 z-50 transition-all duration-300 flex items-center justify-between px-6 py-4",
        scrolled ? "bg-background/80 backdrop-blur-md shadow-sm border-b" : "bg-transparent"
      )}>
        <span className={cn("font-heading font-bold text-lg", scrolled ? "text-primary" : "text-primary")}>
          Hsiu-Wei Chang
        </span>
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className={cn(scrolled ? "text-foreground" : "text-foreground")}>
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-80 bg-sidebar-primary border-r-0">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 md:ml-80 min-h-screen w-full">
        <div className="max-w-5xl mx-auto p-6 md:p-12 pt-24 md:pt-12 animate-in fade-in duration-500 slide-in-from-bottom-4">
          {children}
        </div>
      </main>
    </div>
  );
}
